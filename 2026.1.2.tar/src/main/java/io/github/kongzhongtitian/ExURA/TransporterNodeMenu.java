package io.github.kongzhongtitian.ExURA;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.items.SlotItemHandler;
import org.jetbrains.annotations.NotNull;

public class TransporterNodeMenu extends AbstractContainerMenu {
    public final TransporterNodeBlockEntity blockEntity;
    private final ContainerData data;

    public TransporterNodeMenu(int containerId, Inventory inv, FriendlyByteBuf extraData) {
        this(containerId, inv, inv.player.level().getBlockEntity(extraData.readBlockPos()));
    }

    public TransporterNodeMenu(int containerId, Inventory inv, BlockEntity entity) {
        super(ExURAMenu.TRANSPORTER_NODE_MENU.get(), containerId);

        if (!(entity instanceof TransporterNodeBlockEntity)) {
            throw new IllegalStateException("错误的方块实体类型: " + entity);
        }

        this.blockEntity = (TransporterNodeBlockEntity) entity;
        this.data = blockEntity.data;

        addSlots(inv);
        addPlayerInventory(inv);
        addPlayerHotbar(inv);

        addDataSlots(data);
    }

    private void addSlots(Inventory inv) {
        blockEntity.getCapability(ForgeCapabilities.ITEM_HANDLER).ifPresent(handler -> {
            // 输入槽 (0)
            this.addSlot(new SlotItemHandler(handler, 0, 80, 35) {
                @Override
                public boolean mayPlace(@NotNull ItemStack stack) {
                    return true; // 输入槽可以放任何物品
                }
            });

            // 升级槽 (1-26)
            int upgradeSlotIndex = 1;
            for (int row = 0; row < 4; row++) {
                for (int col = 0; col < 6; col++) {
                    if (upgradeSlotIndex < 27) { // 总共26个升级槽
                        int x = 26 + col * 18;
                        int y = 17 + row * 18;
                        final int slotIndex = upgradeSlotIndex;

                        this.addSlot(new SlotItemHandler(handler, slotIndex, x, y) {
                            @Override
                            public boolean mayPlace(@NotNull ItemStack stack) {
                                // 这里可以添加升级物品的检查逻辑
                                return true;
                            }
                        });
                        upgradeSlotIndex++;
                    }
                }
            }
        });
    }

    private void addPlayerInventory(Inventory playerInventory) {
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 9; ++j) {
                this.addSlot(new Slot(playerInventory, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
            }
        }
    }

    private void addPlayerHotbar(Inventory playerInventory) {
        for (int j = 0; j < 9; ++j) {
            this.addSlot(new Slot(playerInventory, j, 8 + j * 18, 142));
        }
    }

    // 快速移动逻辑
    @Override
    public @NotNull ItemStack quickMoveStack(@NotNull Player player, int index) {
        ItemStack itemstack = ItemStack.EMPTY;
        Slot slot = this.slots.get(index);

        if (slot.hasItem()) {
            ItemStack itemstack1 = slot.getItem();
            itemstack = itemstack1.copy();

            // 从机器槽移动到玩家背包
            if (index < 27) {
                if (!this.moveItemStackTo(itemstack1, 27, this.slots.size(), true)) {
                    return ItemStack.EMPTY;
                }
            }
            // 从玩家背包移动到机器槽
            else {
                // 尝试放入输入槽
                if (!this.moveItemStackTo(itemstack1, 0, 1, false)) {
                    // 如果输入槽满了，尝试放入升级槽
                    if (!this.moveItemStackTo(itemstack1, 1, 27, false)) {
                        return ItemStack.EMPTY;
                    }
                }
            }

            if (itemstack1.isEmpty()) {
                slot.set(ItemStack.EMPTY);
            } else {
                slot.setChanged();
            }
        }

        return itemstack;
    }

    @Override
    public boolean stillValid(Player player) {
        return blockEntity.stillValid(player);
    }
    // 从方块实体构造（带ContainerData参数）- 兼容旧代码
    public TransporterNodeMenu(int containerId, Inventory inv, BlockEntity entity, ContainerData data) {
        super(ExURAMenu.TRANSPORTER_NODE_MENU.get(), containerId);

        if (!(entity instanceof TransporterNodeBlockEntity)) {
            throw new IllegalStateException("错误的方块实体类型: " + entity);
        }

        this.blockEntity = (TransporterNodeBlockEntity) entity;
        this.data = data != null ? data : this.blockEntity.data;

        addSlots(inv);
        addPlayerInventory(inv);
        addPlayerHotbar(inv);

        addDataSlots(this.data);

        ExURA.LOGGER.debug("创建TransporterNodeMenu（兼容版），容器ID: {}", containerId);
    }

    // 获取数据方法
    public int getWorkMode() {
        return data.get(0);
    }

    public int getRange() {
        return data.get(1);
    }

    public int getSpeed() {
        return data.get(2);
    }

    public boolean isWhitelistMode() {
        return data.get(3) == 1;
    }

    public boolean isBlacklistMode() {
        return data.get(4) == 1;
    }

    public int getRangeBonus() {
        return data.get(5);
    }

    public int getSpeedBonus() {
        return data.get(6);
    }

    public boolean hasFilterUpgrade() {
        return data.get(7) == 1;
    }
}