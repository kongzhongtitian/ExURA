package io.github.kongzhongtitian.ExURA;

import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ExURAMenu {
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(ForgeRegistries.MENU_TYPES, ExURA.MODID);

    public static final RegistryObject<MenuType<ResonatorMenu>> RESONATOR_MENU =
            MENUS.register("resonator_menu", () -> IForgeMenuType.create(ResonatorMenu::new));

    public static final RegistryObject<MenuType<FurnaceGeneratorMenu>> FURNACE_GENERATOR_MENU =
            MENUS.register("furnace_generator_menu", () -> IForgeMenuType.create(FurnaceGeneratorMenu::new));

    public static final RegistryObject<MenuType<TransporterNodeMenu>> TRANSPORTER_NODE_MENU =
            MENUS.register("transporter_node_menu", () -> IForgeMenuType.create(TransporterNodeMenu::new));

}
