package io.github.kongzhongtitian.ExURA;

import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@Mod.EventBusSubscriber(modid = ExURA.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ScreenRegister {
    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            MenuScreens.register(ExURAMenu.RESONATOR_MENU.get(), ResonatorScreen::new);
            MenuScreens.register(ExURAMenu.FURNACE_GENERATOR_MENU.get(), FurnaceGeneratorScreen::new);
        });
    }
}