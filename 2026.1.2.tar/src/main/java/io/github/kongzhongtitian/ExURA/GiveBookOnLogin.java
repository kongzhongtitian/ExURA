package io.github.kongzhongtitian.ExURA;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import vazkii.patchouli.api.PatchouliAPI;

@Mod.EventBusSubscriber(modid=ExURA.MODID)//改成你自己的modid
public class GiveBookOnLogin{//改成你自己的类名
        
        @SubscribeEvent
public static void onPlayerLogin(PlayerEvent.PlayerLoggedInEvent event){
        if(event.getEntity().level().isClientSide)return;
        var player=event.getEntity();

        var data=player.getPersistentData();
var key="klux_has_book";//名字随意
        
        if(!data.getBoolean(key)){
        //ResourceLocation第一个参数传你的modid，第二个传你的手册名字
        ItemStack book=PatchouliAPI.get().getBookStack(new ResourceLocation(ExURA.MODID,"exura_book"));
        player.getInventory().add(book);
data.putBoolean(key,true);
}
        }
        }