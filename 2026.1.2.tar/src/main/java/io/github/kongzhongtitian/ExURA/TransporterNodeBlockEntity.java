package io.github.kongzhongtitian.ExURA;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Container;
import net.minecraft.world.Containers;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemStackHandler;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.annotation.Nonnull;
import java.util.*;

public class TransporterNodeBlockEntity extends BlockEntity implements MenuProvider {
    // 槽位定义
    public static final int INPUT_SLOT = 0;
    public static final int UPGRADE_SLOT_START = 1;
    public static final int UPGRADE_SLOT_COUNT = 26;
    public static final int TOTAL_SLOTS = 27;

    // 工作模式
    public enum WorkMode {
        PULL_ONLY,      // 只抽取
        PUSH_ONLY,      // 只输入
        PULL_PUSH       // 既抽取又输入
    }

    // 配置参数
    private static final int MAX_SEARCH_RANGE = 16;  // 最大搜索范围
    private static final int WORK_INTERVAL = 10;     // 工作间隔（刻）

    private WorkMode workMode = WorkMode.PULL_PUSH;
    private int range = 8;                           // 抽取范围
    private int speed = 1;                           // 每次传输数量
    private boolean whitelistMode = true;            // 白名单模式
    private boolean blacklistMode = false;           // 黑名单模式

    // 数据存储
    private final ItemStackHandler itemHandler = new ItemStackHandler(TOTAL_SLOTS) {
        @Override
        protected void onContentsChanged(int slot) {
            setChanged();
        }

        @Override
        public boolean isItemValid(int slot, @Nonnull ItemStack stack) {
            if (slot == INPUT_SLOT) {
                // 输入槽可以放任何物品
                return true;
            } else if (slot >= UPGRADE_SLOT_START && slot < UPGRADE_SLOT_START + UPGRADE_SLOT_COUNT) {
                // 升级槽只放特定升级物品
                return isUpgradeItem(stack);
            }
            return false;
        }

        @Override
        public int getSlotLimit(int slot) {
            if (slot >= UPGRADE_SLOT_START && slot < UPGRADE_SLOT_START + UPGRADE_SLOT_COUNT) {
                // 升级槽只能放1个
                return 1;
            }
            return super.getSlotLimit(slot);
        }
    };

    private LazyOptional<IItemHandler> lazyItemHandler = LazyOptional.empty();

    // 升级效果缓存
    private int cachedRangeBonus = 0;
    private int cachedSpeedBonus = 0;
    private boolean hasFilterUpgrade = false;

    // 数据同步
    protected final ContainerData data = new ContainerData() {
        @Override
        public int get(int index) {
            return switch (index) {
                case 0 -> workMode.ordinal();
                case 1 -> range;
                case 2 -> speed;
                case 3 -> whitelistMode ? 1 : 0;
                case 4 -> blacklistMode ? 1 : 0;
                case 5 -> cachedRangeBonus;
                case 6 -> cachedSpeedBonus;
                case 7 -> hasFilterUpgrade ? 1 : 0;
                default -> 0;
            };
        }

        @Override
        public void set(int index, int value) {
            switch (index) {
                case 0 -> workMode = WorkMode.values()[value];
                case 1 -> range = value;
                case 2 -> speed = value;
                case 3 -> whitelistMode = value == 1;
                case 4 -> blacklistMode = value == 1;
                case 5 -> cachedRangeBonus = value;
                case 6 -> cachedSpeedBonus = value;
                case 7 -> hasFilterUpgrade = value == 1;
            }
        }

        @Override
        public int getCount() {
            return 8;
        }
    };

    private int tickCounter = 0;
    private Set<BlockPos> visitedPipes = new HashSet<>();

    public TransporterNodeBlockEntity(BlockPos pos, BlockState state) {
        super(ExURABlockEntity.TRANSPORTER_NODE.get(), pos, state);
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("block.exura.transporter_node");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory inventory, Player player) {
        return new TransporterNodeMenu(containerId, inventory, this, this.data);
    }
    public boolean stillValid(Player player) {if (this.level == null || this.level.getBlockEntity(this.worldPosition) != this) {
        return false;
    }

    // 检查玩家距离（8格内）
        return player.distanceToSqr(
                (double)this.worldPosition.getX() + 0.5D,
            (double)this.worldPosition.getY() + 0.5D,
            (double)this.worldPosition.getZ() + 0.5D
            ) <= 64.0D;}
    public void drops() {
        if (level == null || level.isClientSide()) return;

        ExURA.LOGGER.debug("传输节点被破坏，掉落物品...");

        // 掉落物品处理器中的所有物品
        Containers.dropContents(level, worldPosition, (Container) itemHandler);

        // 这里还可以添加其他掉落逻辑，比如能量存储的物品化等
    }

    public static void tick(Level level, BlockPos pos, BlockState state, TransporterNodeBlockEntity entity) {
        if (level.isClientSide) return;

        entity.tickCounter++;
        if (entity.tickCounter >= WORK_INTERVAL) {
            entity.tickCounter = 0;

            // 重新计算升级效果
            entity.calculateUpgradeEffects();

            // 根据工作模式执行操作
            switch (entity.workMode) {
                case PULL_ONLY -> entity.pullItems();
                case PUSH_ONLY -> entity.pushItems();
                case PULL_PUSH -> {
                    entity.pullItems();
                    entity.pushItems();
                }
            }
        }
    }

    /**
     * 计算升级效果
     */
    private void calculateUpgradeEffects() {
        cachedRangeBonus = 0;
        cachedSpeedBonus = 0;
        hasFilterUpgrade = false;

        for (int i = UPGRADE_SLOT_START; i < UPGRADE_SLOT_START + UPGRADE_SLOT_COUNT; i++) {
            ItemStack upgrade = itemHandler.getStackInSlot(i);
            if (upgrade.isEmpty()) continue;

            // 检查升级类型
            if (isRangeUpgrade(upgrade)) {
                cachedRangeBonus += 2; // 每个范围升级+2格
            } else if (isSpeedUpgrade(upgrade)) {
                cachedSpeedBonus += 1; // 每个速度升级+1速度
            } else if (isFilterUpgrade(upgrade)) {
                hasFilterUpgrade = true;
            }
        }
    }

    /**
     * 抽取物品逻辑
     */
    private void pullItems() {
        ItemStack inputStack = itemHandler.getStackInSlot(INPUT_SLOT);

        // 如果输入槽已满，不进行抽取
        if (!inputStack.isEmpty() && inputStack.getCount() >= inputStack.getMaxStackSize()) {
            return;
        }

        // 计算实际范围
        int actualRange = range + cachedRangeBonus;

        // 搜索范围内的方块实体
        List<BlockEntity> nearbyMachines = findNearbyMachines(actualRange);

        for (BlockEntity machine : nearbyMachines) {
            if (tryPullFromMachine(machine)) {
                ExURA.LOGGER.debug("从机器 {} 抽取物品成功", machine.getBlockPos());
                return; // 成功抽取一次后就返回
            }
        }
    }

    /**
     * 输入物品逻辑
     */
    private void pushItems() {
        ItemStack inputStack = itemHandler.getStackInSlot(INPUT_SLOT);

        // 如果输入槽为空，不进行输入
        if (inputStack.isEmpty()) {
            return;
        }

        // 清空前一次的访问记录
        visitedPipes.clear();

        // 寻找附近的管道网络
        List<BlockEntity> targetMachines = findMachinesThroughPipes();

        for (BlockEntity machine : targetMachines) {
            if (tryPushToMachine(machine, inputStack)) {
                ExURA.LOGGER.debug("向机器 {} 输入物品成功", machine.getBlockPos());
                return; // 成功输入一次后就返回
            }
        }
    }

    /**
     * 查找附近的机器
     */
    private List<BlockEntity> findNearbyMachines(int searchRange) {
        List<BlockEntity> machines = new ArrayList<>();

        if (level == null) return machines;

        BlockPos startPos = getBlockPos();

        for (int x = -searchRange; x <= searchRange; x++) {
            for (int y = -searchRange; y <= searchRange; y++) {
                for (int z = -searchRange; z <= searchRange; z++) {
                    BlockPos checkPos = startPos.offset(x, y, z);

                    // 跳过自己
                    if (checkPos.equals(startPos)) continue;

                    // 检查距离
                    double distance = Math.sqrt(x*x + y*y + z*z);
                    if (distance > searchRange) continue;

                    BlockEntity entity = level.getBlockEntity(checkPos);
                    if (entity != null && isValidMachine(entity)) {
                        machines.add(entity);
                    }
                }
            }
        }

        // 按距离排序，优先处理近的机器
        machines.sort(Comparator.comparingDouble(machine ->
                machine.getBlockPos().distSqr(startPos)));

        return machines;
    }

    /**
     * 通过管道网络查找机器
     */
    private List<BlockEntity> findMachinesThroughPipes() {
        List<BlockEntity> machines = new ArrayList<>();

        if (level == null) return machines;

        // 从节点开始，广度优先搜索管道网络
        Queue<BlockPos> queue = new LinkedList<>();
        Set<BlockPos> visited = new HashSet<>();

        queue.add(getBlockPos());
        visited.add(getBlockPos());

        while (!queue.isEmpty()) {
            BlockPos current = queue.poll();

            // 检查当前方块的六个方向
            for (Direction direction : Direction.values()) {
                BlockPos neighborPos = current.relative(direction);

                // 跳过已访问的位置
                if (visited.contains(neighborPos)) continue;

                // 检查是否在范围内
                if (getBlockPos().distSqr(neighborPos) > MAX_SEARCH_RANGE * MAX_SEARCH_RANGE) {
                    continue;
                }

                BlockState neighborState = level.getBlockState(neighborPos);

                if (neighborState.getBlock() instanceof TransportPipe) {
                    // 发现管道，加入队列继续搜索
                    queue.add(neighborPos);
                    visited.add(neighborPos);
                    ExURA.LOGGER.debug("发现管道: {}", neighborPos);
                } else {
                    // 检查是否是机器
                    BlockEntity entity = level.getBlockEntity(neighborPos);
                    if (entity != null && isValidMachine(entity) && entity != this) {
                        machines.add(entity);
                        ExURA.LOGGER.debug("发现机器: {}", neighborPos);
                    }
                }
            }
        }

        return machines;
    }

    /**
     * 尝试从机器抽取物品
     */
    private boolean tryPullFromMachine(BlockEntity machine) {
        if (level == null) return false;

        return machine.getCapability(ForgeCapabilities.ITEM_HANDLER).map(handler -> {
            ItemStack inputStack = itemHandler.getStackInSlot(INPUT_SLOT);

            // 检查过滤条件
            if (!passesFilter(inputStack, handler)) {
                return false;
            }

            // 从机器中抽取物品
            for (int i = 0; i < handler.getSlots(); i++) {
                ItemStack extracted = handler.extractItem(i, speed, true);

                if (!extracted.isEmpty()) {
                    // 检查过滤条件
                    if (!passesFilter(extracted, null)) {
                        continue;
                    }

                    // 尝试放入输入槽
                    ItemStack remainder = itemHandler.insertItem(INPUT_SLOT, extracted, false);

                    if (remainder.getCount() < extracted.getCount()) {
                        // 成功放入，实际抽取物品
                        handler.extractItem(i, speed - remainder.getCount(), false);
                        return true;
                    }
                }
            }

            return false;
        }).orElse(false);
    }

    /**
     * 尝试向机器输入物品
     */
    private boolean tryPushToMachine(BlockEntity machine, ItemStack stackToPush) {
        if (level == null || stackToPush.isEmpty()) return false;

        return machine.getCapability(ForgeCapabilities.ITEM_HANDLER).map(handler -> {
            // 检查机器是否能接收物品
            for (int i = 0; i < handler.getSlots(); i++) {
                if (handler.isItemValid(i, stackToPush)) {
                    // 尝试插入
                    ItemStack remainder = handler.insertItem(i, stackToPush.copy(), true);

                    if (remainder.getCount() < stackToPush.getCount()) {
                        // 可以插入，实际执行
                        int toTransfer = stackToPush.getCount() - remainder.getCount();
                        ItemStack transferred = itemHandler.extractItem(INPUT_SLOT, toTransfer, false);

                        if (!transferred.isEmpty()) {
                            handler.insertItem(i, transferred, false);
                            return true;
                        }
                    }
                }
            }

            return false;
        }).orElse(false);
    }

    /**
     * 检查过滤条件
     */
    private boolean passesFilter(ItemStack stack, IItemHandler sourceHandler) {
        if (stack.isEmpty()) return false;

        // 如果有过滤升级，使用升级槽的物品作为过滤条件
        if (hasFilterUpgrade) {
            boolean hasMatch = false;

            for (int i = UPGRADE_SLOT_START; i < UPGRADE_SLOT_START + UPGRADE_SLOT_COUNT; i++) {
                ItemStack filter = itemHandler.getStackInSlot(i);
                if (!filter.isEmpty() && ItemStack.isSameItemSameTags(stack, filter)) {
                    hasMatch = true;
                    break;
                }
            }

            if (whitelistMode && !hasMatch) {
                return false;
            }

            if (blacklistMode && hasMatch) {
                return false;
            }
        }

        return true;
    }

    /**
     * 检查是否是有效的机器
     */
    private boolean isValidMachine(BlockEntity entity) {
        if (entity == null) return false;

        // 跳过自己
        if (entity == this) return false;

        // 检查是否有物品能力
        return entity.getCapability(ForgeCapabilities.ITEM_HANDLER).isPresent();
    }

    /**
     * 检查是否是升级物品
     */
    private boolean isUpgradeItem(ItemStack stack) {
        // 这里可以扩展检查特定的升级物品
        // 暂时返回false，需要你根据实际物品定义
        return false;
    }

    private boolean isRangeUpgrade(ItemStack stack) {
        // 检查是否是范围升级物品
        return false;
    }

    private boolean isSpeedUpgrade(ItemStack stack) {
        // 检查是否是速度升级物品
        return false;
    }

    private boolean isFilterUpgrade(ItemStack stack) {
        // 检查是否是过滤升级物品
        return false;
    }

    // Capability 处理
    @Override
    public void onLoad() {
        super.onLoad();
        lazyItemHandler = LazyOptional.of(() -> itemHandler);
    }

    @Override
    public void invalidateCaps() {
        super.invalidateCaps();
        lazyItemHandler.invalidate();
    }

    @Override
    public @NotNull <T> LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
        if (cap == ForgeCapabilities.ITEM_HANDLER) {
            return lazyItemHandler.cast();
        }

        return super.getCapability(cap, side);
    }

    // NBT 数据持久化
    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);

        tag.put("inventory", itemHandler.serializeNBT());
        tag.putInt("workMode", workMode.ordinal());
        tag.putInt("range", range);
        tag.putInt("speed", speed);
        tag.putBoolean("whitelistMode", whitelistMode);
        tag.putBoolean("blacklistMode", blacklistMode);

        ExURA.LOGGER.debug("保存传输节点数据");
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);

        if (tag.contains("inventory")) {
            itemHandler.deserializeNBT(tag.getCompound("inventory"));
        }

        workMode = WorkMode.values()[tag.getInt("workMode")];
        range = tag.getInt("range");
        speed = tag.getInt("speed");
        whitelistMode = tag.getBoolean("whitelistMode");
        blacklistMode = tag.getBoolean("blacklistMode");

        // 重新计算升级效果
        calculateUpgradeEffects();

        ExURA.LOGGER.debug("加载传输节点数据");
    }

    // Getter 方法
    public IItemHandler getItemHandler() {
        return itemHandler;
    }

    public WorkMode getWorkMode() {
        return workMode;
    }

    public void setWorkMode(WorkMode mode) {
        this.workMode = mode;
        setChanged();
    }

    public int getRange() {
        return range + cachedRangeBonus;
    }

    public void setRange(int range) {
        this.range = range;
        setChanged();
    }

    public int getSpeed() {
        return speed + cachedSpeedBonus;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
        setChanged();
    }

    // 调试方法
    public void printStatus() {
        ExURA.LOGGER.info("传输节点状态:");
        ExURA.LOGGER.info("  位置: {}", getBlockPos());
        ExURA.LOGGER.info("  工作模式: {}", workMode);
        ExURA.LOGGER.info("  范围: {} (+{} 升级)", range, cachedRangeBonus);
        ExURA.LOGGER.info("  速度: {} (+{} 升级)", speed, cachedSpeedBonus);
        ExURA.LOGGER.info("  过滤模式: 白名单={}, 黑名单={}", whitelistMode, blacklistMode);
        ExURA.LOGGER.info("  输入槽: {}", itemHandler.getStackInSlot(INPUT_SLOT));

        int upgradeCount = 0;
        for (int i = UPGRADE_SLOT_START; i < UPGRADE_SLOT_START + UPGRADE_SLOT_COUNT; i++) {
            if (!itemHandler.getStackInSlot(i).isEmpty()) {
                upgradeCount++;
            }
        }
        ExURA.LOGGER.info("  升级槽使用: {}/26", upgradeCount);
    }
}