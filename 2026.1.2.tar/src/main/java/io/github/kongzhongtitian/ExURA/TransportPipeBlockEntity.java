package io.github.kongzhongtitian.ExURA;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemStackHandler;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.annotation.Nonnull;

public class TransportPipeBlockEntity extends BlockEntity {
    // 管道有4个物品槽，用于临时存储传输中的物品
    private static final int PIPE_SLOTS = 4;

    private final ItemStackHandler itemHandler = new ItemStackHandler(PIPE_SLOTS) {
        @Override
        protected void onContentsChanged(int slot) {
            setChanged();
        }

        @Override
        public int getSlotLimit(int slot) {
            return 8; // 管道容量较小
        }
    };

    private LazyOptional<IItemHandler> lazyItemHandler = LazyOptional.empty();

    // 传输方向
    private Direction lastTransferDirection = null;
    private int transferCooldown = 0;

    public TransportPipeBlockEntity(BlockPos pos, BlockState state) {
        super(ExURABlockEntity.TRANSPORT_PIPE.get(), pos, state);
    }

    public static void tick(Level level, BlockPos pos, BlockState state, TransportPipeBlockEntity entity) {
        if (level.isClientSide) return;

        entity.transferCooldown++;
        if (entity.transferCooldown >= 5) { // 每5刻传输一次
            entity.transferCooldown = 0;
            entity.transferItems();
        }
    }

    /**
     * 在管道中传输物品
     */
    private void transferItems() {
        if (level == null) return;

        // 随机选择一个方向开始
        Direction[] directions = Direction.values();
        if (lastTransferDirection != null) {
            // 从上次传输的方向开始
            int startIndex = lastTransferDirection.ordinal();
            for (int i = 0; i < directions.length; i++) {
                Direction dir = directions[(startIndex + i) % directions.length];
                if (tryTransfer(dir)) {
                    lastTransferDirection = dir;
                    break;
                }
            }
        } else {
            // 随机选择方向
            for (Direction dir : directions) {
                if (tryTransfer(dir)) {
                    lastTransferDirection = dir;
                    break;
                }
            }
        }
    }

    /**
     * 尝试向指定方向传输物品
     */
    private boolean tryTransfer(Direction direction) {
        // 检查管道中是否有物品
        for (int slot = 0; slot < itemHandler.getSlots(); slot++) {
            ItemStack stack = itemHandler.getStackInSlot(slot);
            if (!stack.isEmpty()) {
                // 尝试传输物品
                if (transferItemToNeighbor(slot, direction)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 将物品传输到相邻的方块
     */
    private boolean transferItemToNeighbor(int slot, Direction direction) {
        BlockPos neighborPos = worldPosition.relative(direction);
        BlockEntity neighbor = level.getBlockEntity(neighborPos);

        if (neighbor == null) return false;

        return neighbor.getCapability(ForgeCapabilities.ITEM_HANDLER, direction.getOpposite()).map(neighborHandler -> {
            ItemStack stack = itemHandler.getStackInSlot(slot);

            // 尝试插入到相邻方块
            for (int neighborSlot = 0; neighborSlot < neighborHandler.getSlots(); neighborSlot++) {
                if (neighborHandler.isItemValid(neighborSlot, stack)) {
                    ItemStack remainder = neighborHandler.insertItem(neighborSlot, stack.copy(), true);

                    if (remainder.getCount() < stack.getCount()) {
                        // 可以插入，实际执行
                        int toTransfer = stack.getCount() - remainder.getCount();
                        ItemStack extracted = itemHandler.extractItem(slot, toTransfer, false);

                        if (!extracted.isEmpty()) {
                            neighborHandler.insertItem(neighborSlot, extracted, false);
                            return true;
                        }
                    }
                }
            }

            return false;
        }).orElse(false);
    }

    // Capability 处理
    @Override
    public void onLoad() {
        super.onLoad();
        lazyItemHandler = LazyOptional.of(() -> itemHandler);
    }

    @Override
    public void invalidateCaps() {
        super.invalidateCaps();
        lazyItemHandler.invalidate();
    }

    @Override
    public @NotNull <T> LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
        if (cap == ForgeCapabilities.ITEM_HANDLER) {
            return lazyItemHandler.cast();
        }

        return super.getCapability(cap, side);
    }
}