package io.github.kongzhongtitian.ExURA;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.Nullable;

public class TransportPipe extends Block implements EntityBlock {
    // 连接属性
    public static final BooleanProperty NORTH = BooleanProperty.create("north");
    public static final BooleanProperty SOUTH = BooleanProperty.create("south");
    public static final BooleanProperty EAST = BooleanProperty.create("east");
    public static final BooleanProperty WEST = BooleanProperty.create("west");
    public static final BooleanProperty UP = BooleanProperty.create("up");
    public static final BooleanProperty DOWN = BooleanProperty.create("down");

    // 碰撞形状
    protected static final VoxelShape CORE_SHAPE = Block.box(5.0D, 5.0D, 5.0D, 11.0D, 11.0D, 11.0D);
    protected static final VoxelShape[] CONNECTION_SHAPES = {
            Block.box(5.0D, 0.0D, 5.0D, 11.0D, 5.0D, 11.0D), // DOWN
            Block.box(5.0D, 11.0D, 5.0D, 11.0D, 16.0D, 11.0D), // UP
            Block.box(5.0D, 5.0D, 0.0D, 11.0D, 11.0D, 5.0D), // NORTH
            Block.box(5.0D, 5.0D, 11.0D, 11.0D, 11.0D, 16.0D), // SOUTH
            Block.box(11.0D, 5.0D, 5.0D, 16.0D, 11.0D, 11.0D), // EAST
            Block.box(0.0D, 5.0D, 5.0D, 5.0D, 11.0D, 11.0D)  // WEST
    };

    public TransportPipe(Properties properties) {
        super(properties);
        this.registerDefaultState(this.stateDefinition.any()
                .setValue(NORTH, false)
                .setValue(SOUTH, false)
                .setValue(EAST, false)
                .setValue(WEST, false)
                .setValue(UP, false)
                .setValue(DOWN, false));
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new TransportPipeBlockEntity(pos, state);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        VoxelShape shape = CORE_SHAPE;

        if (state.getValue(DOWN)) shape = Block.box(5.0D, 0.0D, 5.0D, 11.0D, 11.0D, 11.0D);
        if (state.getValue(UP)) shape = Block.box(5.0D, 5.0D, 5.0D, 11.0D, 16.0D, 11.0D);
        if (state.getValue(NORTH)) shape = Block.box(5.0D, 5.0D, 0.0D, 11.0D, 11.0D, 11.0D);
        if (state.getValue(SOUTH)) shape = Block.box(5.0D, 5.0D, 5.0D, 11.0D, 11.0D, 16.0D);
        if (state.getValue(EAST)) shape = Block.box(5.0D, 5.0D, 5.0D, 16.0D, 11.0D, 11.0D);
        if (state.getValue(WEST)) shape = Block.box(0.0D, 5.0D, 5.0D, 11.0D, 11.0D, 11.0D);

        return shape;
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        Level level = context.getLevel();
        BlockPos pos = context.getClickedPos();

        return updateConnections(this.defaultBlockState(), level, pos);
    }

    @Override
    public void neighborChanged(BlockState state, Level level, BlockPos pos, Block block, BlockPos fromPos, boolean isMoving) {
        super.neighborChanged(state, level, pos, block, fromPos, isMoving);

        if (!level.isClientSide) {
            BlockState newState = updateConnections(state, level, pos);
            if (!newState.equals(state)) {
                level.setBlock(pos, newState, 3);
            }
        }
    }

    /**
     * 更新管道连接状态
     */
    private BlockState updateConnections(BlockState state, Level level, BlockPos pos) {
        boolean north = canConnectTo(level, pos, Direction.NORTH);
        boolean south = canConnectTo(level, pos, Direction.SOUTH);
        boolean east = canConnectTo(level, pos, Direction.EAST);
        boolean west = canConnectTo(level, pos, Direction.WEST);
        boolean up = canConnectTo(level, pos, Direction.UP);
        boolean down = canConnectTo(level, pos, Direction.DOWN);

        return state.setValue(NORTH, north)
                .setValue(SOUTH, south)
                .setValue(EAST, east)
                .setValue(WEST, west)
                .setValue(UP, up)
                .setValue(DOWN, down);
    }

    /**
     * 检查是否可以连接到指定方向的方块
     */
    private boolean canConnectTo(Level level, BlockPos pos, Direction direction) {
        BlockPos neighborPos = pos.relative(direction);
        BlockState neighborState = level.getBlockState(neighborPos);

        // 可以连接到另一个管道
        if (neighborState.getBlock() instanceof TransportPipe) {
            return true;
        }

        // 可以连接到传输节点
        if (neighborState.getBlock() instanceof TransporterNode) {
            return true;
        }

        // 可以连接到有物品能力的方块实体
        BlockEntity entity = level.getBlockEntity(neighborPos);
        if (entity != null) {
            return entity.getCapability(net.minecraftforge.common.capabilities.ForgeCapabilities.ITEM_HANDLER, direction.getOpposite()).isPresent();
        }

        return false;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(NORTH, SOUTH, EAST, WEST, UP, DOWN);
    }
}